from .hello import Hello

def hello (name):
    text = Hello (name)
    text.say_hello ()